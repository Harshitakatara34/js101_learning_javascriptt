var name = "Harshita katara";
var age = 20;
console.log("Name=", name, "Age=", age);
console.log(typeof (name));
console.log(typeof (age));