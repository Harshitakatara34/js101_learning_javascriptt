var name = "Harshita Katara";
console.log("Name =",name);
var fname = "Mr.Pramod Kumar Katara";
console.log("Father's Name =",fname);
var mname = "Mrs.Kamlesh Katara";
console.log("Mother's Name =",mname);