var one = 1;
var two = 2;
var three = 3;
var four = 4;
var five = 5;
console.log(one+two+three+four+five);