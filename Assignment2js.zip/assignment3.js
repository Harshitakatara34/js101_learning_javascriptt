var one=1;
var two=2*2;
var three=3*3;
var four=4*3;
var five=5*2;
var six=6*2;
console.log(one+two+three+four+five+six);